package com.example.app_bottom_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
