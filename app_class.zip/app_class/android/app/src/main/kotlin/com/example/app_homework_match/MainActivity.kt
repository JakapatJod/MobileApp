package com.example.app_homework_match

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
