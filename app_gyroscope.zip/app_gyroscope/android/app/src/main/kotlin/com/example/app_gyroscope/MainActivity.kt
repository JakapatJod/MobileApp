package com.example.app_gyroscope

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
