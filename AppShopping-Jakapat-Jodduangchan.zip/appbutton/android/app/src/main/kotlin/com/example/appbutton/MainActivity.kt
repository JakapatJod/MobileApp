package com.example.appbutton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
