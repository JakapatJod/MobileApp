package com.example.app_choice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
