package com.example.app_joystick

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
