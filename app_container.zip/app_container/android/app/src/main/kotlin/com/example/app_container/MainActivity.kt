package com.example.app_container

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
