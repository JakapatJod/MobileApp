package com.example.week10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
