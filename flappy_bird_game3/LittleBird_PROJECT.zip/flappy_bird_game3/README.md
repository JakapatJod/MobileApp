# flappy_bird_game

This is a Flappy Bird game built in Flutter using the Flame engine. If you want to know how to create games with Flutter & Flame, visit our YouTube channel to watch the complete Tutorial.

Link: https://youtu.be/zcs8qRBRz7w?si=e4UV_Lf3dbyE9Yj8

## Getting Started

Once you have downloaded this project, you will find all the assets used with in the game.

Here are a few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, please take a look at the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
# flappy_bird_game
