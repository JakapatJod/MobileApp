package com.example.flappy_bird_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
