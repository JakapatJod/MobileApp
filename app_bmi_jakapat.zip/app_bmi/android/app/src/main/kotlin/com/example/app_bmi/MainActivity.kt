package com.example.app_bmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
