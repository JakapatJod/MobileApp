package com.example.app_sql_homework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
