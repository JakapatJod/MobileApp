package com.example.app_sql_bmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
