class foodMenu {
  String name;
  int price;
  String img;

  foodMenu(this.name, this.price, this.img);
}